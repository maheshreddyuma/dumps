#!/bin/bash

collections=("app_inbox_5bebe93c25d705690ffbc758"
"response_campaigns_5bebe93c25d705690ffbc758"
"app_users5bebe93c25d705690ffbc758"
"campaign_statsdata_5bebe93c25d705690ffbc758"
"templates_5bebe93c25d705690ffbc758"
"activecampaign_5bebe93c25d705690ffbc758"
"timely_eventAttributes5bebe93c25d705690ffbc758"
"usertoken_5bebe93c25d705690ffbc758"
"randomAggregates5bebe93c25d705690ffbc758"
"geo_fence_5bebe93c25d705690ffbc758"
"exportjobs_5bebe93c25d705690ffbc758"
"journeys_5bebe93c25d705690ffbc758"
"campaigns_5bebe93c25d705690ffbc758"
"audiencesegment_5bebe93c25d705690ffbc758"
"eventhistory_5bebe93c25d705690ffbc758"
"funnels_5bebe93c25d705690ffbc758"
"aggregates_events_5bebe93c25d705690ffbc758")


for collection in "${collections[@]}"
do
     mongodump --host 172.16.118.43 --port 11018 --db aiproddb  --query='{}' --collection "$collection" --archive="${collection}"
done
