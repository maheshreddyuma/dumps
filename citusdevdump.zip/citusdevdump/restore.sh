#!/bin/bash

# Set your PostgreSQL connection details
HOST="172.16.110.180"
PORT="6432"
USER="postgres"
DB="postgres"
INPUT_DIR="/mnt/citusdevbackup"

# Loop through the dumped files and restore each table
for FILE in $INPUT_DIR/*.sql; do
  TABLE=$(basename $FILE .sql)
  psql -h $HOST -p $PORT -U $USER -d $DB -f $FILE
done

