--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3 (Ubuntu 14.3-1.pgdg20.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: deviceregistration_5bebe93c25d705690ffbc758; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deviceregistration_5bebe93c25d705690ffbc758 (
    id integer NOT NULL,
    device_id uuid,
    msisdn character varying(15),
    email_id character varying(255),
    country_code character varying(5),
    key character varying(10),
    creation_dt integer,
    update_dt integer
);


ALTER TABLE public.deviceregistration_5bebe93c25d705690ffbc758 OWNER TO postgres;

--
-- Name: deviceregistration_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deviceregistration_5bebe93c25d705690ffbc758_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deviceregistration_5bebe93c25d705690ffbc758_id_seq OWNER TO postgres;

--
-- Name: deviceregistration_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deviceregistration_5bebe93c25d705690ffbc758_id_seq OWNED BY public.deviceregistration_5bebe93c25d705690ffbc758.id;


--
-- Name: deviceregistration_5bebe93c25d705690ffbc758 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deviceregistration_5bebe93c25d705690ffbc758 ALTER COLUMN id SET DEFAULT nextval('public.deviceregistration_5bebe93c25d705690ffbc758_id_seq'::regclass);


--
-- Data for Name: deviceregistration_5bebe93c25d705690ffbc758; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deviceregistration_5bebe93c25d705690ffbc758 (id, device_id, msisdn, email_id, country_code, key, creation_dt, update_dt) FROM stdin;
1	c2534f67-f2b3-410b-a6a5-3c4512da93d0	7827188996	saurabh.singh@semusi.com	91	AiReg	\N	\N
2	c2534f67-f2b3-410b-a6a5-3c4512da93d1	7827188997	saurabh.singh@semusi.com1	91	AiReg	\N	\N
\.


--
-- Name: deviceregistration_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deviceregistration_5bebe93c25d705690ffbc758_id_seq', 2, true);


--
-- Name: deviceregistration_5bebe93c25d705690ffbc758 deviceregistration_5bebe93c25d705690ffbc758_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deviceregistration_5bebe93c25d705690ffbc758
    ADD CONSTRAINT deviceregistration_5bebe93c25d705690ffbc758_pkey PRIMARY KEY (id);


--
-- Name: deviceregistration_5bebe93c25d705690ffbc758_idx_device_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX deviceregistration_5bebe93c25d705690ffbc758_idx_device_id ON public.deviceregistration_5bebe93c25d705690ffbc758 USING btree (device_id);


--
-- Name: deviceregistration_5bebe93c25d705690ffbc758_idx_emailid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX deviceregistration_5bebe93c25d705690ffbc758_idx_emailid ON public.deviceregistration_5bebe93c25d705690ffbc758 USING btree (email_id);


--
-- Name: deviceregistration_5bebe93c25d705690ffbc758_idx_msisdn; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX deviceregistration_5bebe93c25d705690ffbc758_idx_msisdn ON public.deviceregistration_5bebe93c25d705690ffbc758 USING btree (msisdn);


--
-- PostgreSQL database dump complete
--

