#!/bin/bash

# Set your PostgreSQL connection details
HOST="172.16.110.180"
PORT="6432"
USER="postgres"
DB="postgres"
OUTPUT_DIR="/mnt/citusdevdump"

# Get a list of tables matching the criteria
TABLES=$(psql -h $HOST -p $PORT -U $USER -d $DB -t -c \
  "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name LIKE '%5bebe93c25d705690ffbc758%';")

# Loop through the tables and dump each one
for TABLE in $TABLES; do
  pg_dump -h $HOST -p $PORT -U $USER -d $DB --table=$TABLE --file=$OUTPUT_DIR/$TABLE.sql
done

