--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3 (Ubuntu 14.3-1.pgdg20.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_users_ab_5bebe93c25d705690ffbc758; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_users_ab_5bebe93c25d705690ffbc758 (
    did character varying NOT NULL,
    platform character varying,
    app_version character varying,
    city character varying,
    platform_version character varying,
    device character varying,
    resolution character varying,
    network character varying
);


ALTER TABLE public.app_users_ab_5bebe93c25d705690ffbc758 OWNER TO postgres;

--
-- Data for Name: app_users_ab_5bebe93c25d705690ffbc758; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_users_ab_5bebe93c25d705690ffbc758 (did, platform, app_version, city, platform_version, device, resolution, network) FROM stdin;
\.


--
-- PostgreSQL database dump complete
--

