--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3 (Ubuntu 14.3-1.pgdg20.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_events_5bebe93c25d705690ffbc758; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_events_5bebe93c25d705690ffbc758 (
    id integer NOT NULL,
    name character varying NOT NULL,
    list jsonb,
    clist jsonb,
    createdat integer,
    updatedat integer,
    servername character varying(100),
    displayname character varying(100)
);


ALTER TABLE public.app_events_5bebe93c25d705690ffbc758 OWNER TO postgres;

--
-- Name: app_events_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.app_events_5bebe93c25d705690ffbc758_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.app_events_5bebe93c25d705690ffbc758_id_seq OWNER TO postgres;

--
-- Name: app_events_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.app_events_5bebe93c25d705690ffbc758_id_seq OWNED BY public.app_events_5bebe93c25d705690ffbc758.id;


--
-- Name: app_events_5bebe93c25d705690ffbc758 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_events_5bebe93c25d705690ffbc758 ALTER COLUMN id SET DEFAULT nextval('public.app_events_5bebe93c25d705690ffbc758_id_seq'::regclass);


--
-- Data for Name: app_events_5bebe93c25d705690ffbc758; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_events_5bebe93c25d705690ffbc758 (id, name, list, clist, createdat, updatedat, servername, displayname) FROM stdin;
3968	LoginDetails	[{"name": "value", "type": "string"}, {"name": "Name", "type": "string"}]	[]	1688980841	1688980841	\N	\N
3962	AvailNow	[{"name": "AvailNowBtn", "type": "string"}, {"name": "OK", "type": "string"}]	[]	1687861240	1687861240	AvailNow	\N
1	GeoData_Received	{}	[]	1653597004	1653597004	GeoData_Received	\N
2	Login	{}	[]	1653683403	1653683403	Login	\N
3	FD_Select	{}	[]	1653683403	1653683403	FD_Select	\N
4	FD_Detail_Verify	{}	[]	1653683403	1653683403	FD_Detail_Verify	\N
5	FD_Topup_Done	{}	[]	1653683403	1653683403	FD_Topup_Done	\N
6	ping_location	{}	[]	1653769804	1653769804	ping_location	\N
7	CompanyDetails	{}	[]	1653942604	1653942604	CompanyDetails	\N
10	PageView	{}	[]	1653942604	1653942604	PageView	\N
8	EmployeeDetails	{}	[]	1653942604	1653942604	EmployeeDetails	\N
9	PageDuration	{}	[]	1653942604	1653942604	PageDuration	\N
11	AddToCart	{}	[]	1654029003	1654029003	AddToCart	\N
13	CartCheckout	{}	[]	1654029003	1654029003	CartCheckout	\N
14	Add To Cart	{}	[]	1654029011	1654029011	Add To Cart	\N
3800	Saurabh v101	[]	[]	1685522327	1685522327	Saurabh v101	\N
18	Payment	{}	[]	1655497803	1655497803	Payment	\N
19	FD_Cancel	{}	[]	1656016203	1656016203	FD_Cancel	\N
20	CoronaCases	{}	[]	1656016203	1656016203	CoronaCases	\N
21	FD_Success	{}	[]	1656016203	1656016203	FD_Success	\N
22	applyForLoan	{}	[]	1656502580	1656502580	applyForLoan	\N
5	11111	[{"name": "testMapKey", "type": "string"}]	[]	1657263251	1657263251	11111	\N
7	11	[{"name": "testMapKey", "type": "string"}]	[]	1657263259	1657263259	11	\N
876	vghnvn	[{"name": "testMapKey", "type": "string"}]	[]	1662357431	1662357431	vghnvn	\N
878	abcf	[{"name": "testMapKey", "type": "string"}]	[]	1662357709	1662357709	abcf	\N
10	a	[{"name": "testMapKey", "type": "string"}]	[]	1657266383	1657266383	a	\N
880	aaaaa	[{"name": "testMapKey", "type": "string"}]	[]	1662357925	1662357925	aaaaa	\N
12	111	[{"name": "testMapKey", "type": "string"}]	[]	1657273976	1657273976	111	\N
882	dfg	[]	[]	1662367071	1662367071	dfg	\N
13	Geofence_deleted	[{"name": "camp_id", "type": "string"}]	[]	1658304762	1658304762	Geofence_deleted	\N
23	Screen_Start	{}	[]	1658435404	1658435404	Screen_Start	\N
25	_sdk_crash	{}	[]	1658435404	1658435404	_sdk_crash	\N
26	applicationDetails	{}	[]	1658435404	1658435404	applicationDetails	\N
28	payOnline	{}	[]	1658435404	1658435404	payOnline	\N
27	creditScore	{}	[]	1658435404	1658435404	creditScore	\N
24	Screen_End	{}	[]	1658435404	1658435404	Screen_End	\N
29	scanQr	{}	[]	1658521803	1658521803	scanQr	\N
31	submitLoanRequest	{}	[]	1658521803	1658521803	submitLoanRequest	\N
30	scanQrToPay	{}	[]	1658521803	1658521803	scanQrToPay	\N
813	asdas	[]	[]	1662114879	1662114879	asdas	\N
32	login	{}	[]	1659126604	1659126604	login	\N
740	Campaign_Deleted	{}	[]	1661751801	1661751801	Campaign_Deleted	\N
3970	CD1	[{"name": "Tech", "type": "string"}]	[]	1689145838	1689145838	\N	\N
289	Guaranteed Emergency Credit Line	{}	[]	1659731403	1659731403	Guaranteed Emergency Credit Line	\N
290	ReactSampleApp	{}	[]	1659731403	1659731403	ReactSampleApp	\N
741	continueForPayment	{}	[]	1661751825	1661751825	continueForPayment	\N
1716	billPayment	{}	[]	1665689403	1665689403	billPayment	\N
3978	Company Details	[{"name": "value", "type": "string"}, {"name": "Name", "type": "string"}]	[]	1689317877	1689317877	\N	\N
22	browse	[{"name": "attribute", "type": "boolean"}]	[]	1659353270	1659353270	browse	\N
1725	access	{}	[]	1665693003	1665693003	access	\N
4012	aaaa	{}	[]	1695151804	1695151804	\N	\N
24	Browse	[{"name": "Home", "type": "boolean"}]	[]	1659359965	1659359965	Browse	\N
1652	rr	[]	[]	1665210150	1665210150	rr	\N
3982	testUserEvent	[]	[]	1689756831	1689756831	\N	\N
33	scroll	{}	[]	1659385803	1659385803	scroll	\N
34	CheckProducts	{}	[]	1659385803	1659385803	CheckProducts	\N
2142	k	[]	[]	1666849484	1666849484	k	\N
2264	cmpanydetails	[{"name": "testSegmentKey", "type": "string"}]	[]	1667213449	1667213449	cmpanydetails	\N
30	Dashboard	[{"name": "ActiveUserDetails", "type": "boolean"}]	[]	1659433112	1659433112	Dashboard	\N
761	123	[]	[]	1661855752	1661855752	123	\N
763	paymentSuccessfull	{}	[]	1661863612	1661863612	paymentSuccessfull	\N
970	df	[]	[]	1662699524	1662699524	df	\N
3989	Event_signIn	[{"name": "login", "type": "string"}]	[]	1689954290	1689954290	\N	\N
205	1111	[{"name": "testMapKey", "type": "string"}]	[]	1659513473	1659513473	1111	\N
1258	gfg	[]	[]	1663568851	1663568851	gfg	\N
704	Campaign_Received	{}	[]	1661406667	1661406667	Campaign_Received	\N
706	boiHome	{}	[]	1661415838	1661415838	boiHome	\N
4014	cd	[]	[]	1695187300	1695187300	\N	\N
4016	Aa	[]	[]	1695283183	1695283183	\N	\N
709	32132132132	[{"name": "testMapKey", "type": "string"}]	[]	1661428668	1661428668	32132132132	\N
1821	Diwali2	[{"name": "Diwali3", "type": "string"}]	[]	1666003347	1666003347	Diwali2	\N
1115	hj	[{"name": "testSegmentKey", "type": "string"}]	[]	1663160717	1663160717	hj	\N
2403	aaa	[]	[]	1667555564	1667555564	aaa	\N
1268	 cc	[]	[]	1663569030	1663569030	 cc	\N
2169	hihhiii	[]	[]	1666937591	1666937591	hihhiii	\N
3993	sd	[]	[]	1690201282	1690201282	\N	\N
4018	FDSuccess	[{"name": "state", "type": "string"}]	[]	1695372291	1695372291	\N	\N
4010	xx	[]	[]	1693215073	1693215073	\N	\N
771	h	{}	[]	1661977803	1661977803	h	\N
1272	fd	[{"name": "testSegmentKey", "type": "string"}]	[]	1663569044	1663569044	fd	\N
788	ddddddd	[]	[]	1662027473	1662027473	ddddddd	\N
1130	3	[]	[]	1663227006	1663227006	3	\N
1132	4	[]	[]	1663227015	1663227015	4	\N
4020	Application Backgrounded	[]	[]	1695884442	1695884442	\N	\N
1752	RTG	[{"name": "123", "type": "string"}]	[]	1665814867	1665814867	RTG	\N
1276	ABCD	[]	[]	1663575197	1663575197	ABCD	\N
4025	Application Installed	[{"name": "build", "type": "string"}, {"name": "version", "type": "string"}]	[]	1696423204	1696423204	\N	\N
4233	loanDetails	{}	[]	1702668603	1702668603	\N	\N
1284	CD	[]	[]	1663584023	1663584023	CD	\N
1286	cgh	[]	[]	1663588802	1663588802	cgh	\N
1008	Rayyan5	[{"name": "testSegmentKey", "type": "string"}]	[]	1662813353	1662813353	Rayyan5	\N
1288	wdd	[]	[]	1663588995	1663588995	wdd	\N
4136	AA	[]	[]	1698315242	1698315242	\N	\N
4111	SBICardPayPre	[]	[]	1698257310	1698257310	\N	\N
4002	CpmpanyDetails	[{"name": "Tech", "type": "string"}]	[]	1692340113	1692340113	\N	\N
4183	cases	[{"name": "type", "type": "string"}, {"name": "country", "type": "string"}]	[]	1699253545	1699253545	\N	\N
4062	RTG22	[{"name": "Ci", "type": "string"}]	[]	1696487260	1696487260	\N	\N
4215	App_ foreground	[{"name": "app", "type": "string"}]	[]	1701073535	1701073535	\N	\N
4221	RecordEvent	[{"name": "sid", "type": "number"}]	[]	1701181186	1701181186	\N	\N
3961	LogoutDetails	[{"name": "value", "type": "string"}, {"name": "Name", "type": "string"}]	[]	1686833453	1686833453	LogoutDetails	\N
1140	1	{}	[]	1663273804	1663273804	1	\N
799	abc	[]	[]	1662108631	1662108631	abc	\N
801	def	[]	[]	1662108634	1662108634	def	\N
804	ghi	[]	[]	1662108638	1662108638	ghi	\N
806	af	[]	[]	1662113770	1662113770	af	\N
285	testEvent	[]	[]	1659676740	1659676740	testEvent	\N
4222	Check event	[]	[]	1701239778	1701239778	\N	\N
286	Send Basic Push	[]	[]	1659676740	1659676740	Send Basic Push	\N
807	ag	[{"name": "mode1", "type": "string"}, {"name": "mode2", "type": "string"}, {"name": "mode3", "type": "string"}]	[]	1662113771	1662113771	ag	\N
288	testEventWithProps	[{"name": "foo", "type": "string"}]	[]	1659676740	1659676740	testEventWithProps	\N
809	as	[]	[]	1662113776	1662113776	as	\N
739	Campaign_Viewed	{}	[]	1661751801	1661751801	Campaign_Viewed	\N
291	HomeScreen	{}	[]	1659731403	1659731403	HomeScreen	\N
742	accountType	{}	[]	1661751825	1661751825	accountType	\N
743	enteredPin	{}	[]	1661751825	1661751825	enteredPin	\N
811	MInun	[]	[]	1662114521	1662114521	MInun	\N
2374	ra	[]	[]	1667477709	1667477709	ra	\N
1717	AboutUs	{}	[]	1665689403	1665689403	AboutUs	\N
744	test	{}	[]	1661805003	1661805003	test	\N
1718	checkout	{}	[]	1665689403	1665689403	checkout	\N
582	addToCart	[]	[]	1660732461	1660732461	addToCart	\N
755	456	[{"name": "mode1", "type": "string"}, {"name": "mode2", "type": "string"}, {"name": "mode3", "type": "string"}]	[]	1661855733	1661855733	456	\N
757	efgh	[]	[]	1661855736	1661855736	efgh	\N
759	ikj	[]	[]	1661855739	1661855739	ikj	\N
1141	BuyNowContinue	{}	[]	1663360204	1663360204	BuyNowContinue	\N
654	Session_Start	{}	[]	1661339004	1661339004	Session_Start	\N
660	Session_End	{}	[]	1661341713	1661341713	Session_End	\N
1730	billpayment	[]	[]	1665729062	1665729062	billpayment	\N
764	abcd	{}	[]	1661891403	1661891403	abcd	\N
703	Campaign_Clicked	{}	[]	1661406667	1661406667	Campaign_Clicked	\N
705	_app_crash	{}	[]	1661415838	1661415838	_app_crash	\N
768	b	[]	[]	1661926767	1661926767	b	\N
769	c	[]	[]	1661926768	1661926768	c	\N
884	g	{}	[]	1662669003	1662669003	g	\N
1261	bbv	[]	[]	1663568854	1663568854	bbv	\N
2389	r	[]	[]	1667540578	1667540578	r	\N
770	i	{}	[]	1661977803	1661977803	i	\N
1264	fg	[]	[]	1663568873	1663568873	fg	\N
971	Rayyan	[]	[]	1662716508	1662716508	Rayyan	\N
2155	hi	[]	[]	1666866880	1666866880	hi	\N
975	hu	[]	[]	1662724355	1662724355	hu	\N
979	gh	[]	[]	1662725601	1662725601	gh	\N
1129	2	[]	[]	1663226998	1663226998	2	\N
2399	Coma	[]	[]	1667551028	1667551028	Coma	\N
1278	rrrr	[]	[]	1663575405	1663575405	rrrr	\N
1280	Rayyan2	[]	[]	1663575932	1663575932	Rayyan2	\N
1282	Mominn	[]	[]	1663577852	1663577852	Mominn	\N
1136	5	[]	[]	1663227023	1663227023	5	\N
1139	Momin	[]	[]	1663230764	1663230764	Momin	\N
1290	xcxx	[]	[]	1663588996	1663588996	xcxx	\N
3171	Hi data	[{"name": "campid", "type": "string"}]	[]	1669794949	1669794949	Hi data	\N
3964	LoanAmount	[{"name": "LoanAmt", "type": "number"}, {"name": "LoanTenure", "type": "number"}, {"name": "Next", "type": "string"}, {"name": "Back", "type": "string"}, {"name": "EMIAmt", "type": "number"}, {"name": "ClickX", "type": "string"}]	[]	1687861378	1687861378	LoanAmount	\N
3787	Saurabh v95	[]	[]	1685522082	1685522082	Saurabh v95	\N
2257	hihi	[]	[]	1667203212	1667203212	hihi	\N
3972	cd1	[{"name": "tech", "type": "string"}]	[]	1689147228	1689147228	\N	\N
4113	SBICardPayPre1	[]	[]	1698257555	1698257555	\N	\N
4004	COmpanyDetails	[]	[]	1692349219	1692349219	\N	\N
4230	UserId	[{"name": "UserId", "type": "string"}]	[]	1701862171	1701862171	\N	\N
4011	My Profile	{}	[]	1693251005	1693251005	\N	\N
4138	ddd	[]	[]	1698343635	1698343635	\N	\N
2144	CompanyDetais	[]	[]	1666851210	1666851210	CompanyDetais	\N
2152	okok	[]	[]	1666860095	1666860095	okok	\N
2998	6a54sf	[{"name": "ds564f", "type": "string"}]	[]	1669273331	1669273331	6a54sf	\N
3172	myEventShailesh	{}	[]	1673379003	1673379003	myEventShailesh	\N
3450	Event Test	[{"name": "ClickedMenuBtn", "type": "string"}, {"name": "User", "type": "string"}, {"name": "CLickedSubmitBtn", "type": "string"}, {"name": "TestRun", "type": "string"}, {"name": "AppName", "type": "string"}]	[]	1674186221	1674186221	Event Test	\N
1765	R2	[{"name": "R3", "type": "string"}]	[]	1665835962	1665835962	R2	\N
1297	vv	[]	[]	1663595112	1663595112	vv	\N
883	utm	{}	[]	1662582603	1662582603	utm	\N
1294	fh	[{"name": "testSegmentKey", "type": "string"}]	[]	1663595111	1663595111	fh	\N
1828	Sayyan2	[{"name": "Sayyan3", "type": "string"}]	[]	1666011911	1666011911	Sayyan2	\N
1602	clicks	{}	[]	1665039678	1665039678	clicks	\N
1399	SampleApp	{}	[]	1664397004	1664397004	SampleApp	\N
4205	Amit	[{"name": "DisplayName", "type": "string"}]	[]	1699948162	1699948162	\N	\N
4023	Application Opened	[{"name": "from_background", "type": "boolean"}]	[]	1695884481	1695884481	\N	\N
3795	Saurabh v99	[]	[]	1685522088	1685522088	Saurabh v99	\N
4029	RTG2	[{"name": "Tech", "type": "string"}]	[]	1696486859	1696486859	\N	\N
4060	RTG21	[{"name": "Ci", "type": "string"}]	[]	1696487254	1696487254	\N	\N
4094	t1	[]	[]	1696495036	1696495036	\N	\N
4232	MyProfile	[{"name": "AB", "type": "string"}, {"name": "CD", "type": "string"}]	[]	1701926415	1701926415	\N	\N
4114	ss	[]	[]	1698257892	1698257892	\N	\N
4124	email	[]	[]	1698258805	1698258805	\N	\N
4196	t	[]	[]	1699517881	1699517881	\N	\N
4206	xyz	[{"name": "test", "type": "string"}]	[]	1699973463	1699973463	\N	\N
1955	qe	[{"name": "testSegmentKey", "type": "string"}]	[]	1666332007	1666332007	qe	\N
2141	ok	[]	[]	1666847091	1666847091	ok	\N
2393	rt	[]	[]	1667544999	1667544999	rt	\N
2292	kk	[]	[]	1667292821	1667292821	kk	\N
2401	asd	[]	[]	1667554642	1667554642	asd	\N
2102	companydetails	[]	[]	1666770064	1666770064	companydetails	\N
2304	stage	[]	[]	1667302120	1667302120	stage	\N
3421	TEST_EVENT	[]	[]	1673506673	1673506673	TEST_EVENT	\N
2335	HomePage	[{"name": "value", "type": "string"}, {"name": "Name", "type": "string"}]	[]	1667378302	1667378302	HomePage	\N
3441	Event Rose	[{"name": "productCost", "type": "number"}, {"name": "productId", "type": "string"}, {"name": "userid", "type": "string"}]	[]	1674034421	1674034421	Event Rose	\N
4225	check event 2	[{"name": "Ch only", "type": "string"}]	[]	1701241556	1701241556	\N	\N
4228	Fhytyugyftyyu	[]	[]	1701253086	1701253086	\N	\N
3966	LoanEMI	[{"name": "BackButton", "type": "string"}, {"name": "Next", "type": "string"}, {"name": "EMIStartDate", "type": "string"}, {"name": "OK", "type": "string"}, {"name": "Back", "type": "string"}, {"name": "ClickX", "type": "string"}]	[]	1687861452	1687861452	LoanEMI	\N
3789	Saurabh v96	[]	[]	1685522083	1685522083	Saurabh v96	\N
3974	dsf	[{"name": "sdfdsf", "type": "string"}]	[]	1689148676	1689148676	\N	\N
3987	Event_SignIn	[{"name": "time", "type": "string"}, {"name": "userid", "type": "string"}]	[]	1689845215	1689845215	\N	\N
3803	Saurabh v103	[]	[]	1685522329	1685522329	Saurabh v103	\N
4030	RTG99	[{"name": "City", "type": "string"}]	[]	1696486943	1696486943	\N	\N
4032	RTG3	[{"name": "Ci", "type": "string"}]	[]	1696487000	1696487000	\N	\N
4048	RTG11	[{"name": "Ci", "type": "string"}]	[]	1696487066	1696487066	\N	\N
4116	ss1	[]	[]	1698257944	1698257944	\N	\N
4140	emailr	[]	[]	1698347831	1698347831	\N	\N
4211	Event	[{"name": "onClick", "type": "string"}, {"name": "Name", "type": "string"}]	[]	1700460415	1700460415	\N	\N
4217	App_foreground	[{"name": "ab", "type": "string"}]	[]	1701073785	1701073785	\N	\N
3451	Inbox_Read	{}	[]	1676489405	1676489405	Inbox_Read	\N
3553	HLVisit	[{"name": "productId", "type": "string"}, {"name": "openTrigger", "type": "string"}]	[]	1676884753	1676884753	HLVisit	\N
4036	RTG5	[{"name": "Ci", "type": "string"}]	[]	1696487003	1696487003	\N	\N
4038	RTG7	[{"name": "Ci", "type": "string"}]	[]	1696487008	1696487008	\N	\N
4096	t2	[]	[]	1696503149	1696503149	\N	\N
4198	y	[]	[]	1699553811	1699553811	\N	\N
4212	testevent	[{"name": "onClick", "type": "string"}]	[]	1700725223	1700725223	\N	\N
4218	EventName	[{"name": "onClick", "type": "string"}, {"name": "testevent", "type": "string"}, {"name": "name", "type": "string"}]	[]	1701076811	1701076811	\N	\N
4227	@#%@	[{"name": "Ch only", "type": "string"}]	[]	1701241667	1701241667	\N	\N
3555	HLStartJourney	[{"name": "constitution", "type": "string"}, {"name": "customerType", "type": "string"}]	[]	1676884757	1676884757	HLStartJourney	\N
3557	HLAddInfo	[{"name": "customerType", "type": "string"}, {"name": "loanAmount", "type": "string"}]	[]	1676884762	1676884762	HLAddInfo	\N
3559	HLLeadGen	[{"name": "leadID", "type": "string"}]	[]	1676884769	1676884769	HLLeadGen	\N
3561	etisalat_shop_quick_links	[{"name": "SubCategory", "type": "string"}]	[]	1677077379	1677077379	etisalat_shop_quick_links	\N
3563	RR	[]	[]	1677483734	1677483734	RR	\N
3565	654654	[]	[]	1677505327	1677505327	654654	\N
3567	VerifyOTP	[{"name": "customerType", "type": "string"}]	[]	1677824881	1677824881	VerifyOTP	\N
3569	HLApplyNow	[{"name": "customerType", "type": "string"}]	[]	1677825071	1677825071	HLApplyNow	\N
3572	HLVerifyOTP	[{"name": "customerType", "type": "string"}]	[]	1677825350	1677825350	HLVerifyOTP	\N
3574	RechargeStatus	[{"name": "RechargeDone", "type": "boolean"}]	[]	1678194372	1678194372	RechargeStatus	\N
3577	Event Test 001	[{"name": "ClickedMenuBtn", "type": "string"}, {"name": "User", "type": "string"}, {"name": "CLickedSubmitBtn", "type": "string"}, {"name": "TestRun", "type": "string"}, {"name": "AppName", "type": "string"}]	[]	1678865395	1678865395	Event Test 001	\N
3580	WebViewAppICE	[{"name": "OnPressed", "type": "string"}]	[]	1678877331	1678877331	WebViewAppICE	\N
3581	company	[]	[]	1679310492	1679310492	company	\N
3583	company details	[{"name": "mode1", "type": "string"}, {"name": "mode2", "type": "string"}, {"name": "mode3", "type": "string"}]	[]	1679310642	1679310642	company details	\N
3599	Saurabh v2	[]	[]	1685521751	1685521751	Saurabh v2	\N
3600	Saurabh	[]	[]	1685521751	1685521751	Saurabh	\N
3603	Saurabh v3	[]	[]	1685521861	1685521861	Saurabh v3	\N
3605	Saurabh v4	[]	[]	1685521864	1685521864	Saurabh v4	\N
3607	Saurabh v5	[]	[]	1685521867	1685521867	Saurabh v5	\N
3609	Saurabh v6	[]	[]	1685521871	1685521871	Saurabh v6	\N
3612	Saurabh v7	[]	[]	1685521872	1685521872	Saurabh v7	\N
3613	Saurabh v8	[]	[]	1685521874	1685521874	Saurabh v8	\N
3791	Saurabh v97	[]	[]	1685522085	1685522085	Saurabh v97	\N
3793	Saurabh v98	[]	[]	1685522086	1685522086	Saurabh v98	\N
3976	CD2	[{"name": "tech", "type": "string"}]	[]	1689156379	1689156379	\N	\N
4118	ss12	[]	[]	1698258024	1698258024	\N	\N
4142	emailrt	[]	[]	1698347898	1698347898	\N	\N
4039	RTG6	[{"name": "Ci", "type": "string"}]	[]	1696487008	1696487008	\N	\N
4058	RTG20	[{"name": "Ci", "type": "string"}]	[]	1696487252	1696487252	\N	\N
4064	RTG23	[{"name": "Ci", "type": "string"}]	[]	1696487273	1696487273	\N	\N
3619	Saurabh v11	[]	[]	1685521882	1685521882	Saurabh v11	\N
3645	Saurabh v24	[]	[]	1685521913	1685521913	Saurabh v24	\N
3659	Saurabh v31	[]	[]	1685521935	1685521935	Saurabh v31	\N
3675	Saurabh v39	[]	[]	1685521952	1685521952	Saurabh v39	\N
3719	Saurabh v61	[]	[]	1685522004	1685522004	Saurabh v61	\N
3722	Saurabh v62	[]	[]	1685522004	1685522004	Saurabh v62	\N
3616	Saurabh v9	[]	[]	1685521877	1685521877	Saurabh v9	\N
3665	Saurabh v34	[]	[]	1685521943	1685521943	Saurabh v34	\N
3799	Saurabh v102	[]	[]	1685522327	1685522327	Saurabh v102	\N
4034	RTG4	[{"name": "Ci", "type": "string"}]	[]	1696487000	1696487000	\N	\N
4166	testAAA	[{"name": "value", "type": "string"}, {"name": "Name", "type": "string"}]	[]	1699068725	1699068725	\N	\N
3703	Saurabh v53	[]	[]	1685521988	1685521988	Saurabh v53	\N
4188	app_navv	[{"name": "testCase", "type": "string"}, {"name": "category", "type": "string"}]	[]	1699257179	1699257179	\N	\N
3617	Saurabh v10	[]	[]	1685521878	1685521878	Saurabh v10	\N
4120	em	[]	[]	1698258796	1698258796	\N	\N
4042	RTG8	[{"name": "Ci", "type": "string"}]	[]	1696487010	1696487010	\N	\N
4143	ds	{}	[]	1698348604	1698348604	\N	\N
4100	RT	[]	[]	1696831005	1696831005	\N	\N
4102	Reinstall	[]	[]	1697613983	1697613983	\N	\N
4104	My Profile1	[]	[]	1697780443	1697780443	\N	\N
3807	Saurabh v105	[]	[]	1685522332	1685522332	Saurabh v105	\N
3622	Saurabh v12	[]	[]	1685521883	1685521883	Saurabh v12	\N
3626	Saurabh v14	[]	[]	1685521888	1685521888	Saurabh v14	\N
3643	Saurabh v23	[]	[]	1685521911	1685521911	Saurabh v23	\N
3651	Saurabh v27	[]	[]	1685521924	1685521924	Saurabh v27	\N
3669	Saurabh v36	[]	[]	1685521946	1685521946	Saurabh v36	\N
3677	Saurabh v40	[]	[]	1685521954	1685521954	Saurabh v40	\N
3693	Saurabh v48	[]	[]	1685521977	1685521977	Saurabh v48	\N
3627	Saurabh v15	[]	[]	1685521889	1685521889	Saurabh v15	\N
3731	Saurabh v67	[]	[]	1685522015	1685522015	Saurabh v67	\N
4044	RTG9	[{"name": "Ci", "type": "string"}]	[]	1696487054	1696487054	\N	\N
4070	RTG26	[{"name": "Ci", "type": "string"}]	[]	1696487756	1696487756	\N	\N
4099	RTG1	[]	[]	1696583458	1696583458	\N	\N
4169	testBBB	[{"name": "value", "type": "string"}, {"name": "Name", "type": "string"}]	[]	1699074820	1699074820	\N	\N
4202	Product	[{"name": "DisplayName", "type": "string"}]	[]	1699592477	1699592477	\N	\N
3623	Saurabh v13	[]	[]	1685521885	1685521885	Saurabh v13	\N
3635	Saurabh v19	[]	[]	1685521899	1685521899	Saurabh v19	\N
3639	Saurabh v21	[]	[]	1685521904	1685521904	Saurabh v21	\N
4122	emem	[]	[]	1698258801	1698258801	\N	\N
4191	app_navga	[{"name": "testCase", "type": "string"}, {"name": "category", "type": "string"}]	[]	1699261436	1699261436	\N	\N
3661	Saurabh v32	[]	[]	1685521938	1685521938	Saurabh v32	\N
3797	Saurabh v100	[]	[]	1685522093	1685522093	Saurabh v100	\N
3671	Saurabh v37	[]	[]	1685521947	1685521947	Saurabh v37	\N
3729	Saurabh v66	[]	[]	1685522014	1685522014	Saurabh v66	\N
3657	Saurabh v30	[]	[]	1685521932	1685521932	Saurabh v30	\N
3699	Saurabh v51	[]	[]	1685521985	1685521985	Saurabh v51	\N
4072	RTG28	[{"name": "Ci", "type": "string"}]	[]	1696487756	1696487756	\N	\N
4106	tss	[]	[]	1697784137	1697784137	\N	\N
4172	testCCC	[{"name": "SpecialAttack", "type": "number"}, {"name": "Attack", "type": "number"}, {"name": "Cured", "type": "boolean"}, {"name": "Defense", "type": "number"}]	[]	1699075023	1699075023	\N	\N
12	BuyNow	{}	[]	1654029003	1654029003	BuyNow	\N
2	SemusiEvent	[{"name": "mode1", "type": "string"}, {"name": "mode2", "type": "string"}, {"name": "mode3", "type": "string"}]	[]	1654248648	1654248648	SemusiEvent	\N
3785	Saurabh v94	[]	[]	1685522080	1685522080	Saurabh v94	\N
15	hybridEvent	{}	[]	1654288203	1654288203	hybridEvent	\N
16	home	{}	[]	1654720203	1654720203	home	\N
17		{}	[]	1655238604	1655238604		\N
3	test for link	[{"name": "productId", "type": "string"}, {"name": "skuId", "type": "string"}, {"name": "commerceItemId", "type": "string"}, {"name": "displayName", "type": "string"}, {"name": "deepLink", "type": "string"}, {"name": "Category", "type": "string"}]	[]	1655441082	1655441082	test for link	\N
4108	tss1	[]	[]	1697784743	1697784743	\N	\N
2104	employeedetails	[]	[]	1666770130	1666770130	employeedetails	\N
2302	rrr	[]	[]	1667301296	1667301296	rrr	\N
4046	RTG10	[{"name": "Ci", "type": "string"}]	[]	1696487066	1696487066	\N	\N
4066	RTG24	[{"name": "Ci", "type": "string"}]	[]	1696487287	1696487287	\N	\N
4076	RTG29	[{"name": "Ci", "type": "string"}]	[]	1696487758	1696487758	\N	\N
4127	Product Impressions	[]	[]	1698261439	1698261439	\N	\N
2332	App Open	[]	[]	1667364432	1667364432	App Open	\N
1396	aa	[]	[]	1663843460	1663843460	aa	\N
1398	Rayyan1	[]	[]	1663844252	1663844252	Rayyan1	\N
1858	sayyan2	[{"name": "sayyan3", "type": "string"}]	[]	1666093143	1666093143	sayyan2	\N
1706	CompanyDetailsCompanyDetI	[]	[]	1665558145	1665558145	CompanyDetailsCompanyDetI	\N
1713	oneevent	[]	[]	1665643906	1665643906	oneevent	\N
1715	ABC	[{"name": "testSegmentKey", "type": "string"}]	[]	1665644011	1665644011	ABC	\N
3629	Saurabh v16	[]	[]	1685521891	1685521891	Saurabh v16	\N
3815	Saurabh v109	[]	[]	1685522338	1685522338	Saurabh v109	\N
3683	Saurabh v43	[]	[]	1685521961	1685521961	Saurabh v43	\N
3688	Saurabh v45	[]	[]	1685521965	1685521965	Saurabh v45	\N
3692	Saurabh v47	[]	[]	1685521972	1685521972	Saurabh v47	\N
3695	Saurabh v49	[]	[]	1685521980	1685521980	Saurabh v49	\N
3711	Saurabh v57	[]	[]	1685521995	1685521995	Saurabh v57	\N
3713	Saurabh v58	[]	[]	1685521996	1685521996	Saurabh v58	\N
3717	Saurabh v60	[]	[]	1685522001	1685522001	Saurabh v60	\N
3723	Saurabh v63	[]	[]	1685522007	1685522007	Saurabh v63	\N
3726	Saurabh v64	[]	[]	1685522009	1685522009	Saurabh v64	\N
3631	Saurabh v17	[]	[]	1685521894	1685521894	Saurabh v17	\N
3681	Saurabh v42	[]	[]	1685521960	1685521960	Saurabh v42	\N
3705	Saurabh v54	[]	[]	1685521990	1685521990	Saurabh v54	\N
3811	Saurabh v107	[]	[]	1685522335	1685522335	Saurabh v107	\N
4174	testDDD	[{"name": "SpecialAttack", "type": "number"}, {"name": "Attack", "type": "number"}, {"name": "Cured", "type": "boolean"}, {"name": "Defense", "type": "number"}]	[]	1699075044	1699075044	\N	\N
3633	Saurabh v18	[]	[]	1685521896	1685521896	Saurabh v18	\N
3813	Saurabh v108	[]	[]	1685522337	1685522337	Saurabh v108	\N
3679	Saurabh v41	[]	[]	1685521957	1685521957	Saurabh v41	\N
4078	RTG30	[{"name": "Ci", "type": "string"}]	[]	1696487758	1696487758	\N	\N
4150	j	[]	[]	1698657602	1698657602	\N	\N
4092	RTG41	[{"name": "Ci", "type": "string"}]	[]	1696488251	1696488251	\N	\N
3805	Saurabh v104	[]	[]	1685522330	1685522330	Saurabh v104	\N
3709	Saurabh v56	[]	[]	1685521993	1685521993	Saurabh v56	\N
4050	RTG13	[{"name": "Ci", "type": "string"}]	[]	1696487068	1696487068	\N	\N
4074	RTG27	[{"name": "Ci", "type": "string"}]	[]	1696487756	1696487756	\N	\N
4080	RTG31	[{"name": "Ci", "type": "string"}]	[]	1696487959	1696487959	\N	\N
4084	RTG37	[{"name": "Ci", "type": "string"}]	[]	1696487993	1696487993	\N	\N
4176	testFFF	[{"name": "SpecialAttack", "type": "number"}, {"name": "Attack", "type": "number"}, {"name": "Cured", "type": "boolean"}, {"name": "Defense", "type": "number"}]	[]	1699075474	1699075474	\N	\N
3637	Saurabh v20	[]	[]	1685521902	1685521902	Saurabh v20	\N
3647	Saurabh v25	[]	[]	1685521918	1685521918	Saurabh v25	\N
3649	Saurabh v26	[]	[]	1685521921	1685521921	Saurabh v26	\N
4130	Company details	[]	[]	1698308550	1698308550	\N	\N
4082	RTG36	[{"name": "Ci", "type": "string"}]	[]	1696487963	1696487963	\N	\N
4152	event	[]	[]	1698900285	1698900285	\N	\N
3667	Saurabh v35	[]	[]	1685521944	1685521944	Saurabh v35	\N
3685	Saurabh v44	[]	[]	1685521963	1685521963	Saurabh v44	\N
3690	Saurabh v46	[]	[]	1685521968	1685521968	Saurabh v46	\N
3641	Saurabh v22	[]	[]	1685521908	1685521908	Saurabh v22	\N
3663	Saurabh v33	[]	[]	1685521939	1685521939	Saurabh v33	\N
4053	RTG12	[{"name": "Ci", "type": "string"}]	[]	1696487068	1696487068	\N	\N
3673	Saurabh v38	[]	[]	1685521949	1685521949	Saurabh v38	\N
4178	testhhh	[{"name": "SpecialAttack", "type": "number"}, {"name": "Attack", "type": "number"}, {"name": "Cured", "type": "boolean"}, {"name": "Defense", "type": "number"}]	[]	1699075677	1699075677	\N	\N
3809	Saurabh v106	[]	[]	1685522333	1685522333	Saurabh v106	\N
3653	Saurabh v28	[]	[]	1685521925	1685521925	Saurabh v28	\N
4132	sss	[]	[]	1698309110	1698309110	\N	\N
4086	RTG38	[{"name": "Ci", "type": "string"}]	[]	1696488217	1696488217	\N	\N
4154	app_nav	[{"name": "value", "type": "string"}, {"name": "Name", "type": "string"}]	[]	1698920760	1698920760	\N	\N
3656	Saurabh v29	[]	[]	1685521930	1685521930	Saurabh v29	\N
3697	Saurabh v50	[]	[]	1685521983	1685521983	Saurabh v50	\N
3701	Saurabh v52	[]	[]	1685521987	1685521987	Saurabh v52	\N
3707	Saurabh v55	[]	[]	1685521991	1685521991	Saurabh v55	\N
3727	Saurabh v65	[]	[]	1685522011	1685522011	Saurabh v65	\N
3733	Saurabh v68	[]	[]	1685522017	1685522017	Saurabh v68	\N
4054	RTG14	[{"name": "Ci", "type": "string"}]	[]	1696487070	1696487070	\N	\N
4180	testiii	[{"name": "SpecialAttack", "type": "number"}, {"name": "Attack", "type": "number"}, {"name": "Cured", "type": "boolean"}, {"name": "Defense", "type": "number"}]	[]	1699076950	1699076950	\N	\N
3715	Saurabh v59	[]	[]	1685521999	1685521999	Saurabh v59	\N
4134	sss1	[]	[]	1698314694	1698314694	\N	\N
4068	RTG25	[{"name": "Ci", "type": "string"}]	[]	1696487310	1696487310	\N	\N
4088	RTG39	[{"name": "Ci", "type": "string"}]	[]	1696488229	1696488229	\N	\N
3817	Saurabh v110	[]	[]	1685522343	1685522343	Saurabh v110	\N
3735	Saurabh v69	[]	[]	1685522020	1685522020	Saurabh v69	\N
4056	RTG15	[{"name": "Ci", "type": "string"}]	[]	1696487074	1696487074	\N	\N
4090	RTG40	[{"name": "Ci", "type": "string"}]	[]	1696488238	1696488238	\N	\N
3737	Saurabh v70	[]	[]	1685522023	1685522023	Saurabh v70	\N
3739	Saurabh v71	[]	[]	1685522025	1685522025	Saurabh v71	\N
3741	Saurabh v72	[]	[]	1685522026	1685522026	Saurabh v72	\N
3744	Saurabh v73	[]	[]	1685522028	1685522028	Saurabh v73	\N
3745	Saurabh v74	[]	[]	1685522030	1685522030	Saurabh v74	\N
3748	Saurabh v75	[]	[]	1685522031	1685522031	Saurabh v75	\N
3749	Saurabh v76	[]	[]	1685522033	1685522033	Saurabh v76	\N
3752	Saurabh v77	[]	[]	1685522036	1685522036	Saurabh v77	\N
3753	Saurabh v78	[]	[]	1685522039	1685522039	Saurabh v78	\N
3755	Saurabh v79	[]	[]	1685522041	1685522041	Saurabh v79	\N
3757	Saurabh v80	[]	[]	1685522044	1685522044	Saurabh v80	\N
3759	Saurabh v81	[]	[]	1685522047	1685522047	Saurabh v81	\N
3761	Saurabh v82	[]	[]	1685522050	1685522050	Saurabh v82	\N
3763	Saurabh v83	[]	[]	1685522053	1685522053	Saurabh v83	\N
3765	Saurabh v84	[]	[]	1685522056	1685522056	Saurabh v84	\N
3768	Saurabh v85	[]	[]	1685522060	1685522060	Saurabh v85	\N
3769	Saurabh v86	[]	[]	1685522061	1685522061	Saurabh v86	\N
3771	Saurabh v87	[]	[]	1685522064	1685522064	Saurabh v87	\N
3773	Saurabh v88	[]	[]	1685522067	1685522067	Saurabh v88	\N
3775	Saurabh v89	[]	[]	1685522069	1685522069	Saurabh v89	\N
3777	Saurabh v90	[]	[]	1685522072	1685522072	Saurabh v90	\N
3779	Saurabh v91	[]	[]	1685522074	1685522074	Saurabh v91	\N
3781	Saurabh v92	[]	[]	1685522075	1685522075	Saurabh v92	\N
3783	Saurabh v93	[]	[]	1685522077	1685522077	Saurabh v93	\N
\.


--
-- Name: app_events_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.app_events_5bebe93c25d705690ffbc758_id_seq', 4237, true);


--
-- Name: app_events_5bebe93c25d705690ffbc758 app_events_5bebe93c25d705690ffbc758_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_events_5bebe93c25d705690ffbc758
    ADD CONSTRAINT app_events_5bebe93c25d705690ffbc758_pkey PRIMARY KEY (name);


--
-- Name: app_events_5bebe93c25d705690ffbc758_idx_clist; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX app_events_5bebe93c25d705690ffbc758_idx_clist ON public.app_events_5bebe93c25d705690ffbc758 USING btree (clist);


--
-- Name: app_events_5bebe93c25d705690ffbc758_idx_list; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX app_events_5bebe93c25d705690ffbc758_idx_list ON public.app_events_5bebe93c25d705690ffbc758 USING btree (list);


--
-- Name: app_events_5bebe93c25d705690ffbc758_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX app_events_5bebe93c25d705690ffbc758_name_idx ON public.app_events_5bebe93c25d705690ffbc758 USING btree (name);


--
-- PostgreSQL database dump complete
--

