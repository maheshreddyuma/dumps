--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3 (Ubuntu 14.3-1.pgdg20.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attributes_5bebe93c25d705690ffbc758; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attributes_5bebe93c25d705690ffbc758 (
    id integer NOT NULL,
    key character varying NOT NULL,
    name character varying NOT NULL,
    datatype character varying,
    datemax date,
    datemin date,
    intmax integer,
    intmin integer,
    floatmax double precision,
    floatmin double precision,
    servername character varying(100),
    displayname character varying(100)
);


ALTER TABLE public.attributes_5bebe93c25d705690ffbc758 OWNER TO postgres;

--
-- Name: attributes_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attributes_5bebe93c25d705690ffbc758_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attributes_5bebe93c25d705690ffbc758_id_seq OWNER TO postgres;

--
-- Name: attributes_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attributes_5bebe93c25d705690ffbc758_id_seq OWNED BY public.attributes_5bebe93c25d705690ffbc758.id;


--
-- Name: attributes_5bebe93c25d705690ffbc758 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attributes_5bebe93c25d705690ffbc758 ALTER COLUMN id SET DEFAULT nextval('public.attributes_5bebe93c25d705690ffbc758_id_seq'::regclass);


--
-- Data for Name: attributes_5bebe93c25d705690ffbc758; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attributes_5bebe93c25d705690ffbc758 (id, key, name, datatype, datemax, datemin, intmax, intmin, floatmax, floatmin, servername, displayname) FROM stdin;
383	LogoutDetails	Cured	boolean	\N	\N	0	0	0	0	\N	\N
389	CD1	Tech	string	\N	\N	0	0	0	0	\N	\N
393	Company Details	Name	string	\N	\N	0	0	0	0	\N	\N
394	Company Details	value	string	\N	\N	0	0	0	0	\N	\N
395	Event_SignIn	login	string	\N	\N	0	0	0	0	\N	\N
401	Event_signIn	png	string	\N	\N	0	0	0	0	\N	\N
402	CompanyDetails	Tech	string	\N	\N	0	0	0	0	\N	\N
404	CpmpanyDetails	Tech	string	\N	\N	0	0	0	0	\N	\N
405	EmployeeDetails	Tech	string	\N	\N	0	0	0	0	\N	\N
7	Campaign_Clicked	campid	string	\N	\N	123790681	0	0	0	campid	\N
406	xx	testSegmentKey	string	\N	\N	0	0	0	0	\N	\N
408	CompanyDetails	Clicked	string	\N	\N	0	0	0	0	\N	\N
409	ReactSampleApp	Name	string	\N	\N	0	0	0	0	\N	\N
411	FD_Success	state	string	\N	\N	0	0	0	0	\N	\N
413	Event Rose	event	string	\N	\N	0	0	0	0	\N	\N
422	Application Opened	from_background	boolean	\N	\N	0	0	0	0	\N	\N
423	Application Installed	build	int	\N	\N	1	1	0	0	\N	\N
426	Application Opened	version	float	\N	\N	0	0	1	1	\N	\N
427	RTG2	Tech	string	\N	\N	0	0	0	0	\N	\N
428	RTG99	City	string	\N	\N	0	0	0	0	\N	\N
429	RTG3	Ci	string	\N	\N	0	0	0	0	\N	\N
436	RTG10	Ci	string	\N	\N	0	0	0	0	\N	\N
444	RTG22	Ci	string	\N	\N	0	0	0	0	\N	\N
460	RTG3	Tech	string	\N	\N	0	0	0	0	\N	\N
30	PageDuration	duration	int	\N	\N	22702812	1	0	0	duration	\N
384	LogoutDetails	Attack	int	\N	\N	10	10	0	0	\N	\N
385	LogoutDetails	Defense	float	\N	\N	0	0	10.5	10.5	\N	\N
386	LogoutDetails	SpecialAttack	int	\N	\N	10	10	0	0	\N	\N
390	cd1	tech	string	\N	\N	0	0	0	0	\N	\N
396	Event_SignIn	userid	string	\N	\N	0	0	0	0	\N	\N
1	ReactSampleApp	AppName	string	\N	\N	0	0	0	0	AppName	\N
403	CompanyDetails	Tehc	string	\N	\N	0	0	0	0	\N	\N
407	My Profile	Clicked	string	\N	\N	0	0	0	0	\N	\N
410	ReactSampleApp	value	string	\N	\N	0	0	0	0	\N	\N
412	FDSuccess	state	string	\N	\N	0	0	0	0	\N	\N
415	Event Rose	userId	int	\N	\N	1210012	1210012	0	0	\N	\N
424	Application Installed	version	float	\N	\N	0	0	1	1	\N	\N
430	RTG4	Ci	string	\N	\N	0	0	0	0	\N	\N
433	RTG7	Ci	string	\N	\N	0	0	0	0	\N	\N
437	RTG11	Ci	string	\N	\N	0	0	0	0	\N	\N
445	RTG23	Ci	string	\N	\N	0	0	0	0	\N	\N
448	RTG26	Ci	string	\N	\N	0	0	0	0	\N	\N
450	RTG28	Ci	string	\N	\N	0	0	0	0	\N	\N
453	RTG31	Ci	string	\N	\N	0	0	0	0	\N	\N
454	RTG36	Ci	string	\N	\N	0	0	0	0	\N	\N
455	RTG37	Ci	string	\N	\N	0	0	0	0	\N	\N
456	RTG38	Ci	string	\N	\N	0	0	0	0	\N	\N
387	LoginDetails	Name	string	\N	\N	0	0	0	0	\N	\N
391	CD1	tech	string	\N	\N	0	0	0	0	\N	\N
397	Event_SignIn	password	datetime	2023-01-01	2023-01-01	0	0	0	0	\N	\N
398	Event_SignIn	Enter Key	string	\N	\N	0	0	0	0	\N	\N
399	Event_signIn	login	string	\N	\N	0	0	0	0	\N	\N
416	Event Rose	context	object	\N	\N	0	0	0	0	\N	\N
425	Application Opened	build	int	\N	\N	1	1	0	0	\N	\N
431	RTG5	Ci	string	\N	\N	0	0	0	0	\N	\N
438	RTG13	Ci	string	\N	\N	0	0	0	0	\N	\N
442	RTG20	Ci	string	\N	\N	0	0	0	0	\N	\N
446	RTG24	Ci	string	\N	\N	0	0	0	0	\N	\N
388	LoginDetails	value	string	\N	\N	0	0	0	0	\N	\N
392	CD2	tech	string	\N	\N	0	0	0	0	\N	\N
400	Event_signIn	hg	string	\N	\N	0	0	0	0	\N	\N
417	Event Rose	messageId	string	\N	\N	0	0	0	0	\N	\N
432	RTG6	Ci	string	\N	\N	0	0	0	0	\N	\N
439	RTG14	Ci	string	\N	\N	0	0	0	0	\N	\N
443	RTG21	Ci	string	\N	\N	0	0	0	0	\N	\N
449	RTG27	Ci	string	\N	\N	0	0	0	0	\N	\N
2	ReactSampleApp	ClickedMenuBtn	string	\N	\N	0	0	0	0	ClickedMenuBtn	\N
94	FD_Topup_Done	cart	object	\N	\N	0	0	0	0	cart	\N
418	Event Rose	timestamp	datetime	2023-09-28	2023-09-28	0	0	0	0	\N	\N
434	RTG8	Ci	string	\N	\N	0	0	0	0	\N	\N
440	RTG12	Ci	string	\N	\N	0	0	0	0	\N	\N
452	RTG30	Ci	string	\N	\N	0	0	0	0	\N	\N
3	ReactSampleApp	CLickedSubmitBtn	string	\N	\N	0	0	0	0	CLickedSubmitBtn	\N
139	paymentSuccessfull	skuId	int	\N	\N	345	345	0	0	skuId	\N
5	Login	id	string	\N	\N	0	0	0	0	id	\N
6	Login	state	boolean	\N	\N	0	0	0	0	state	\N
140	paymentSuccessfull	Category	string	\N	\N	0	0	0	0	Category	\N
8	PageDuration	name	string	\N	\N	0	0	0	0	name	\N
9	PageView	view	string	\N	\N	0	0	0	0	view	\N
10	PageView	visit	int	\N	\N	1	1	0	0	visit	\N
11	PageView	domain	string	\N	\N	0	0	0	0	domain	\N
12	PageView	referrer	datetime	4200-01-01	4200-01-01	0	0	0	0	referrer	\N
13	FD_Select	products	object	\N	\N	0	0	0	0	products	\N
14	CompanyDetails	Name	string	\N	\N	0	0	0	0	Name	\N
15	CompanyDetails	value	string	\N	\N	0	0	0	0	value	\N
16	CoronaCases	Cured	boolean	\N	\N	0	0	0	0	Cured	\N
17	CoronaCases	Attack	int	\N	\N	10	10	0	0	Attack	\N
18	CoronaCases	Defense	float	\N	\N	0	0	10.5	10.5	Defense	\N
19	CoronaCases	SpecialAttack	int	\N	\N	10	10	0	0	SpecialAttack	\N
20	EmployeeDetails	Name	string	\N	\N	0	0	0	0	Name	\N
21	EmployeeDetails	value	string	\N	\N	0	0	0	0	value	\N
22	ping_location	location_update	object	\N	\N	0	0	0	0	location_update	\N
23	Session_End	sid	string	\N	\N	0	0	0	0	sid	\N
24	testEventWithProps	foo	string	\N	\N	0	0	0	0	foo	\N
141	paymentSuccessfull	productId	int	\N	\N	123	123	0	0	productId	\N
26	scroll	view	string	\N	\N	0	0	0	0	view	\N
145	456	mode1	string	\N	\N	0	0	0	0	mode1	\N
28	scroll	domain	string	\N	\N	0	0	0	0	domain	\N
146	456	mode2	string	\N	\N	0	0	0	0	mode2	\N
147	456	mode3	string	\N	\N	0	0	0	0	mode3	\N
31	FD_Detail_Verify	PAN	string	\N	\N	0	0	0	0	PAN	\N
32	FD_Detail_Verify	DepositType	string	\N	\N	0	0	0	0	DepositType	\N
33	creditScore	Category	string	\N	\N	0	0	0	0	Category	\N
34	creditScore	validOTP	string	\N	\N	0	0	0	0	validOTP	\N
35	creditScore	customerId	int	\N	\N	876	876	0	0	customerId	\N
36	creditScore	displayName	string	\N	\N	0	0	0	0	displayName	\N
37	applyForLoan	type	string	\N	\N	0	0	0	0	type	\N
38	applyForLoan	Category	string	\N	\N	0	0	0	0	Category	\N
39	applyForLoan	customerId	int	\N	\N	876	876	0	0	customerId	\N
40	applyForLoan	displayName	string	\N	\N	0	0	0	0	displayName	\N
41	applicationDetails	Category	string	\N	\N	0	0	0	0	Category	\N
42	applicationDetails	customerId	int	\N	\N	876	876	0	0	customerId	\N
95	FD_Cancel	cart	object	\N	\N	0	0	0	0	cart	\N
43	applicationDetails	displayName	string	\N	\N	0	0	0	0	displayName	\N
44	submitLoanRequest	LoanEMI	int	\N	\N	5000	5000	0	0	LoanEMI	\N
45	submitLoanRequest	Category	string	\N	\N	0	0	0	0	Category	\N
46	submitLoanRequest	LoanAmount	int	\N	\N	500000	500000	0	0	LoanAmount	\N
47	submitLoanRequest	displayName	string	\N	\N	0	0	0	0	displayName	\N
48	submitLoanRequest	LoanApproved	string	\N	\N	0	0	0	0	LoanApproved	\N
49	submitLoanRequest	LoanDuration	string	\N	\N	0	0	0	0	LoanDuration	\N
50	boiHome	Category	string	\N	\N	0	0	0	0	Category	\N
51	boiHome	customerId	int	\N	\N	876	876	0	0	customerId	\N
52	boiHome	displayName	string	\N	\N	0	0	0	0	displayName	\N
53	Browse	Home	boolean	\N	\N	0	0	0	0	Home	\N
54	Browse	SetupNewChatbot	boolean	\N	\N	0	0	0	0	SetupNewChatbot	\N
55	login	LoginMethod	string	\N	\N	0	0	0	0	LoginMethod	\N
56	login	LoginStatus	boolean	\N	\N	0	0	0	0	LoginStatus	\N
57	home	skuId	int	\N	\N	345	345	0	0	skuId	\N
58	home	Category	string	\N	\N	0	0	0	0	Category	\N
59	home	productId	int	\N	\N	123	123	0	0	productId	\N
60	home	displayName	string	\N	\N	0	0	0	0	displayName	\N
61	home	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
62		testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
63	1111	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
64	Screen_Start	name	string	\N	\N	0	0	0	0	name	\N
65	Screen_Start	time	int	\N	\N	1000000000	1000000000	0	0	time	\N
66	Screen_End	name	string	\N	\N	0	0	0	0	name	\N
67	Screen_End	time	int	\N	\N	1000000000	1000000000	0	0	time	\N
151	ddddddd	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
69	Dashboard	ActiveUserDetails	boolean	\N	\N	0	0	0	0	ActiveUserDetails	\N
70	Dashboard	ChurnDetails	boolean	\N	\N	0	0	0	0	ChurnDetails	\N
71	Dashboard	EventDetails	boolean	\N	\N	0	0	0	0	EventDetails	\N
72	Browse	Campaigns	boolean	\N	\N	0	0	0	0	Campaigns	\N
73	Browse	Dashboard	boolean	\N	\N	0	0	0	0	Dashboard	\N
74	browse	attribute	boolean	\N	\N	0	0	0	0	attribute	\N
75	Browse	AppDashboard	boolean	\N	\N	0	0	0	0	AppDashboard	\N
76	CheckProducts	skuId	int	\N	\N	345	345	0	0	skuId	\N
77	CheckProducts	Category	string	\N	\N	0	0	0	0	Category	\N
78	CheckProducts	deepLink	string	\N	\N	0	0	0	0	deepLink	\N
79	CheckProducts	productId	int	\N	\N	123	123	0	0	productId	\N
80	CheckProducts	displayName	string	\N	\N	0	0	0	0	displayName	\N
81	CheckProducts	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
82	Browse	SetupNewApp	boolean	\N	\N	0	0	0	0	SetupNewApp	\N
83	browse	Home	boolean	\N	\N	0	0	0	0	Home	\N
84	browse	AppDashboard	boolean	\N	\N	0	0	0	0	AppDashboard	\N
156	asdas	mode2	string	\N	\N	0	0	0	0	mode2	\N
157	asdas	mode3	string	\N	\N	0	0	0	0	mode3	\N
178	1	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
350	hybridEvent	Category	string	\N	\N	0	0	0	0	Category	\N
68	Screen_End	duration	int	\N	\N	7	1	0	0	duration	\N
142	paymentSuccessfull	displayName	string	\N	\N	0	0	0	0	displayName	\N
143	paymentSuccessfull	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
148	i	mode1	string	\N	\N	0	0	0	0	mode1	\N
149	i	mode2	string	\N	\N	0	0	0	0	mode2	\N
150	i	mode3	string	\N	\N	0	0	0	0	mode3	\N
152	ag	mode1	string	\N	\N	0	0	0	0	mode1	\N
153	ag	mode2	string	\N	\N	0	0	0	0	mode2	\N
155	asdas	mode1	string	\N	\N	0	0	0	0	mode1	\N
158	vghnvn	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
160	aaaaa	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
162	utm	utm_medium	string	\N	\N	0	0	0	0	utm_medium	\N
163	utm	utm_source	string	\N	\N	0	0	0	0	utm_source	\N
165	g	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
167	hu	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
169	Rayyan	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
170	Rayyan5	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
85	BuyNow	InStock	string	\N	\N	0	0	0	0	InStock	\N
86	BuyNow	DisplayName	string	\N	\N	0	0	0	0	DisplayName	\N
87	BuyNow	SubCategory	string	\N	\N	0	0	0	0	SubCategory	\N
88	BuyNow	DisplayNameAr	string	\N	\N	0	0	0	0	DisplayNameAr	\N
89	BuyNow	PaymentAmount	int	\N	\N	123	123	0	0	PaymentAmount	\N
172	Add To Cart	Category	string	\N	\N	0	0	0	0	Category	\N
174	Add To Cart	productId	int	\N	\N	123	123	0	0	productId	\N
176	Add To Cart	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
351	hybridEvent	displayName	string	\N	\N	0	0	0	0	displayName	\N
90	11111	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
91	11	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
92	a	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
93	111	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
96	FD_Cancel	state	boolean	\N	\N	0	0	0	0	state	\N
177	hj	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
179	2	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
99	Payment	skuId	int	\N	\N	345	345	0	0	skuId	\N
100	Payment	Category	string	\N	\N	0	0	0	0	Category	\N
101	Payment	deepLink	string	\N	\N	0	0	0	0	deepLink	\N
102	Payment	productId	int	\N	\N	123	123	0	0	productId	\N
103	Payment	displayName	string	\N	\N	0	0	0	0	displayName	\N
104	Payment	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
180	3	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
184	AddToCart	skuId	int	\N	\N	345	345	0	0	skuId	\N
105	Geofence_deleted	camp_id	string	\N	\N	0	0	0	0	camp_id	\N
106	_sdk_crash	stack	string	\N	\N	0	0	0	0	stack	\N
107	_sdk_crash	version	int	\N	\N	2522	2522	0	0	version	\N
108	_sdk_crash	platform	string	\N	\N	0	0	0	0	platform	\N
109	payOnline	skuId	int	\N	\N	345	345	0	0	skuId	\N
110	payOnline	Category	string	\N	\N	0	0	0	0	Category	\N
111	payOnline	productId	int	\N	\N	123	123	0	0	productId	\N
112	payOnline	displayName	string	\N	\N	0	0	0	0	displayName	\N
113	payOnline	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
114	scanQr	skuId	int	\N	\N	345	345	0	0	skuId	\N
115	scanQr	Category	string	\N	\N	0	0	0	0	Category	\N
116	scanQr	productId	int	\N	\N	123	123	0	0	productId	\N
117	scanQr	displayName	string	\N	\N	0	0	0	0	displayName	\N
118	scanQr	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
119	scanQrToPay	skuId	int	\N	\N	345	345	0	0	skuId	\N
120	scanQrToPay	Category	string	\N	\N	0	0	0	0	Category	\N
121	scanQrToPay	productId	int	\N	\N	123	123	0	0	productId	\N
122	scanQrToPay	displayName	string	\N	\N	0	0	0	0	displayName	\N
123	scanQrToPay	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
124	continueForPayment	skuId	int	\N	\N	345	345	0	0	skuId	\N
125	continueForPayment	Category	string	\N	\N	0	0	0	0	Category	\N
126	continueForPayment	productId	int	\N	\N	123	123	0	0	productId	\N
127	continueForPayment	displayName	string	\N	\N	0	0	0	0	displayName	\N
128	continueForPayment	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
129	accountType	skuId	int	\N	\N	345	345	0	0	skuId	\N
130	accountType	Category	string	\N	\N	0	0	0	0	Category	\N
131	accountType	productId	int	\N	\N	123	123	0	0	productId	\N
132	accountType	displayName	string	\N	\N	0	0	0	0	displayName	\N
133	accountType	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
134	enteredPin	skuId	int	\N	\N	345	345	0	0	skuId	\N
135	enteredPin	Category	string	\N	\N	0	0	0	0	Category	\N
136	enteredPin	productId	int	\N	\N	123	123	0	0	productId	\N
137	enteredPin	displayName	string	\N	\N	0	0	0	0	displayName	\N
138	enteredPin	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
185	AddToCart	Category	string	\N	\N	0	0	0	0	Category	\N
187	AddToCart	productId	int	\N	\N	123	123	0	0	productId	\N
188	AddToCart	displayName	string	\N	\N	0	0	0	0	displayName	\N
191	BuyNow	Category	string	\N	\N	0	0	0	0	Category	\N
193	BuyNow	productId	int	\N	\N	123	123	0	0	productId	\N
195	BuyNow	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
197	BuyNow	category	string	\N	\N	0	0	0	0	category	\N
233	123	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
234	abc	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
352	utm	utm_id	int	\N	\N	123	123	0	0	utm_id	\N
27	scroll	width	int	\N	\N	1921	195	0	0	width	\N
235	EmployeeDetails	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
236	Rayyan1	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
242	rr	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
144	test	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
154	ag	mode3	string	\N	\N	0	0	0	0	mode3	\N
159	abcf	testMapKey	string	\N	\N	0	0	0	0	testMapKey	\N
161	utm	utm_term	string	\N	\N	0	0	0	0	utm_term	\N
243	Rayyan2	Rayyan3	string	\N	\N	0	0	0	0	Rayyan3	\N
244	boiHome	Name	string	\N	\N	0	0	0	0	Name	\N
245	boiHome	value	string	\N	\N	0	0	0	0	value	\N
246	boiHome	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
247	CompanyDetailsCompanyDetI	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
248	BuyNow	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
249	g	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
250	accountType	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
251	billPayment	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
252	browse	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
356	CompanyDetails	Source	string	\N	\N	0	0	0	0	Source	\N
253	AboutUs	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
164	utm	utm_campaign	int	\N	\N	1234	123	0	0	utm_campaign	\N
166	CompanyDetails	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
168	gh	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
171	Add To Cart	skuId	int	\N	\N	345	345	0	0	skuId	\N
173	Add To Cart	deepLink	string	\N	\N	0	0	0	0	deepLink	\N
175	Add To Cart	displayName	string	\N	\N	0	0	0	0	displayName	\N
181	4	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
182	5	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
183	Momin	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
186	AddToCart	deepLink	string	\N	\N	0	0	0	0	deepLink	\N
189	AddToCart	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
190	BuyNow	skuId	int	\N	\N	345	345	0	0	skuId	\N
237	aa	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
192	BuyNow	deepLink	string	\N	\N	0	0	0	0	deepLink	\N
238	Login	name	string	\N	\N	0	0	0	0	name	\N
254	clicks	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
419	Event Rose	properties	object	\N	\N	0	0	0	0	\N	\N
194	BuyNow	displayName	string	\N	\N	0	0	0	0	displayName	\N
196	BuyNow	stock	string	\N	\N	0	0	0	0	stock	\N
198	BuyNowContinue	skuId	int	\N	\N	345	345	0	0	skuId	\N
199	BuyNowContinue	Category	string	\N	\N	0	0	0	0	Category	\N
200	BuyNowContinue	deepLink	string	\N	\N	0	0	0	0	deepLink	\N
201	BuyNowContinue	productId	int	\N	\N	123	123	0	0	productId	\N
202	BuyNowContinue	displayName	string	\N	\N	0	0	0	0	displayName	\N
203	BuyNowContinue	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
204	CartCheckout	skuId	int	\N	\N	345	345	0	0	skuId	\N
205	CartCheckout	Category	string	\N	\N	0	0	0	0	Category	\N
206	CartCheckout	deepLink	string	\N	\N	0	0	0	0	deepLink	\N
207	CartCheckout	productId	int	\N	\N	123	123	0	0	productId	\N
208	CartCheckout	displayName	string	\N	\N	0	0	0	0	displayName	\N
209	CartCheckout	commerceItemId	int	\N	\N	876	876	0	0	commerceItemId	\N
212	clicks	type	string	\N	\N	0	0	0	0	type	\N
213	clicks	view	string	\N	\N	0	0	0	0	view	\N
214	clicks	width	int	\N	\N	980	980	0	0	width	\N
215	clicks	domain	string	\N	\N	0	0	0	0	domain	\N
216	clicks	height	int	\N	\N	1669	1669	0	0	height	\N
255	checkout	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
256	oneevent	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
210	clicks	x	int	\N	\N	686	678	0	0	x	\N
211	clicks	y	int	\N	\N	59	58	0	0	y	\N
217	gfg	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
218	bbv	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
219	fg	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
220	 cc	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
221	df	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
222	fh	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
223	fd	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
224	vv	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
225	cgh	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
226	wdd	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
227	xcxx	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
228	Mominn	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
229	ABCD	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
230	rrrr	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
231	Rayyan2	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
232	CD	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
239	SampleApp	AppName	string	\N	\N	0	0	0	0	AppName	\N
240	SampleApp	ClickedMenuBtn	string	\N	\N	0	0	0	0	ClickedMenuBtn	\N
241	SampleApp	CLickedSubmitBtn	string	\N	\N	0	0	0	0	CLickedSubmitBtn	\N
257	ABC	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
258	Payment	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
259	access	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
260	browse	Name	string	\N	\N	0	0	0	0	Name	\N
261	browse	value	string	\N	\N	0	0	0	0	value	\N
262	checkout	Name	string	\N	\N	0	0	0	0	Name	\N
263	checkout	value	string	\N	\N	0	0	0	0	value	\N
264	billpayment	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
265	RTG	123	int	\N	\N	456	456	0	0	123	\N
266	R2	R3	string	\N	\N	0	0	0	0	R3	\N
267	Diwali2	Diwali3	string	\N	\N	0	0	0	0	Diwali3	\N
268	Sayyan2	Sayyan3	string	\N	\N	0	0	0	0	Sayyan3	\N
269	sayyan2	sayyan3	string	\N	\N	0	0	0	0	sayyan3	\N
270	qe	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
271	h	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
272	companydetails	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
273	employeedetails	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
274	okok	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
275	ok	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
276	k	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
277	CompanyDetais	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
278	hi	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
279	login	status	string	\N	\N	0	0	0	0	status	\N
280	hihhiii	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
281	hihi	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
282	cmpanydetails	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
283	kk	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
284	rrr	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
285	stage	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
313	TEST_EVENT	key	string	\N	\N	0	0	0	0	key	\N
314	Event Rose	userid	string	\N	\N	0	0	0	0	userid	\N
315	Event Rose	productId	string	\N	\N	0	0	0	0	productId	\N
317	Event Test	User	string	\N	\N	0	0	0	0	User	\N
318	Event Test	AppName	string	\N	\N	0	0	0	0	AppName	\N
319	Event Test	TestRun	string	\N	\N	0	0	0	0	TestRun	\N
320	Event Test	ClickedMenuBtn	string	\N	\N	0	0	0	0	ClickedMenuBtn	\N
321	Event Test	CLickedSubmitBtn	string	\N	\N	0	0	0	0	CLickedSubmitBtn	\N
316	Event Rose	productCost	int	\N	\N	220	120	0	0	productCost	\N
353	LogoutDetails	Name	string	\N	\N	0	0	0	0	Name	\N
329	etisalat_shop_quick_links	SubCategory	string	\N	\N	0	0	0	0	SubCategory	\N
339	Event Test 001	User	string	\N	\N	0	0	0	0	User	\N
333	AddToCart	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
286	App Open	Name	string	\N	\N	0	0	0	0	Name	\N
287	App Open	value	string	\N	\N	0	0	0	0	value	\N
288	HomePage	Name	string	\N	\N	0	0	0	0	Name	\N
289	HomePage	value	string	\N	\N	0	0	0	0	value	\N
290	ra	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
291	Coma	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
292	r	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
293	rt	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
294	asd	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
295	aaa	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
296	a	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
29	scroll	height	int	\N	\N	4339	648	0	0	height	\N
323	HLAddInfo	customerType	string	\N	\N	0	0	0	0	customerType	\N
325	HLStartJourney	constitution	string	\N	\N	0	0	0	0	constitution	\N
326	HLStartJourney	customerType	string	\N	\N	0	0	0	0	customerType	\N
328	HLVisit	openTrigger	string	\N	\N	0	0	0	0	openTrigger	\N
330	654654	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
297	111	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
334	Session_Start	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
331	R2	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
298	6a54sf	ds564f	string	\N	\N	0	0	0	0	ds564f	\N
299	utm	utm_content	string	\N	\N	0	0	0	0	utm_content	\N
300	myEventShailesh	onClick	string	\N	\N	0	0	0	0	onClick	\N
301	ReactSampleApp	LinkPAN	string	\N	\N	0	0	0	0	LinkPAN	\N
302	ReactSampleApp	ApplyPAN	string	\N	\N	0	0	0	0	ApplyPAN	\N
303	ReactSampleApp	IssueType	string	\N	\N	0	0	0	0	IssueType	\N
304	ReactSampleApp	ApplyForIPO	string	\N	\N	0	0	0	0	ApplyForIPO	\N
305	ReactSampleApp	BankAccount	string	\N	\N	0	0	0	0	BankAccount	\N
306	ReactSampleApp	DematAccount	string	\N	\N	0	0	0	0	DematAccount	\N
307	ReactSampleApp	FailureMessage	string	\N	\N	0	0	0	0	FailureMessage	\N
308	ReactSampleApp	Quantity	string	\N	\N	0	0	0	0	Quantity	\N
309	ReactSampleApp	BidAmount	string	\N	\N	0	0	0	0	BidAmount	\N
310	ReactSampleApp	TotalValue	string	\N	\N	0	0	0	0	TotalValue	\N
311	ReactSampleApp	HighBidValue	string	\N	\N	0	0	0	0	HighBidValue	\N
312	ReactSampleApp	InvestorCategory	string	\N	\N	0	0	0	0	InvestorCategory	\N
332	RR	testSegmentKey	string	\N	\N	0	0	0	0	testSegmentKey	\N
335	HLVerifyOTP	customerType	string	\N	\N	0	0	0	0	customerType	\N
336	HLApplyNow	customerType	string	\N	\N	0	0	0	0	customerType	\N
337	VerifyOTP	customerType	string	\N	\N	0	0	0	0	customerType	\N
338	RechargeStatus	RechargeDone	boolean	\N	\N	0	0	0	0	RechargeDone	\N
327	HLVisit	productId	int	\N	\N	65472462	65172462	0	0	productId	\N
322	HLAddInfo	loanAmount	int	\N	\N	2000000	1000000	0	0	loanAmount	\N
324	HLLeadGen	leadID	int	\N	\N	489763	481763	0	0	leadID	\N
340	Event Test 001	AppName	string	\N	\N	0	0	0	0	AppName	\N
341	Event Test 001	TestRun	string	\N	\N	0	0	0	0	TestRun	\N
342	Event Test 001	ClickedMenuBtn	string	\N	\N	0	0	0	0	ClickedMenuBtn	\N
343	Event Test 001	CLickedSubmitBtn	string	\N	\N	0	0	0	0	CLickedSubmitBtn	\N
420	Event Rose	anonymousId	string	\N	\N	0	0	0	0	\N	\N
344	WebViewAppICE	OnPressed	string	\N	\N	0	0	0	0	OnPressed	\N
345	WebViewAppICE	User	string	\N	\N	0	0	0	0	User	\N
346	WebViewAppICE	AppName	string	\N	\N	0	0	0	0	AppName	\N
354	LogoutDetails	value	string	\N	\N	0	0	0	0	value	\N
355	CompanyDetails	Source 	string	\N	\N	0	0	0	0	Source 	\N
357	Session_Start	sid	string	\N	\N	0	0	0	0	sid	\N
358	AvailNow	OK	string	\N	\N	0	0	0	0	OK	\N
25	scroll	y	int	\N	\N	4390	624	3603.5	0	y	\N
347	company details	mode1	string	\N	\N	0	0	0	0	mode1	\N
348	company details	mode2	string	\N	\N	0	0	0	0	mode2	\N
349	company details	mode3	string	\N	\N	0	0	0	0	mode3	\N
359	AvailNow	AvailNowBtn	string	\N	\N	0	0	0	0	AvailNowBtn	\N
360	LoanAmount	Back	string	\N	\N	0	0	0	0	Back	\N
361	LoanAmount	Next	string	\N	\N	0	0	0	0	Next	\N
362	LoanAmount	ClickX	string	\N	\N	0	0	0	0	ClickX	\N
363	LoanAmount	EMIAmt	int	\N	\N	3704	3704	0	0	EMIAmt	\N
364	LoanAmount	LoanAmt	int	\N	\N	146500	146500	0	0	LoanAmt	\N
365	LoanAmount	LoanTenure	int	\N	\N	53	53	0	0	LoanTenure	\N
366	LoanEMI	OK	string	\N	\N	0	0	0	0	OK	\N
367	LoanEMI	Back	string	\N	\N	0	0	0	0	Back	\N
368	LoanEMI	Next	string	\N	\N	0	0	0	0	Next	\N
369	LoanEMI	ClickX	string	\N	\N	0	0	0	0	ClickX	\N
370	LoanEMI	BackButton	string	\N	\N	0	0	0	0	BackButton	\N
371	LoanEMI	EMIStartDate	datetime	2023-06-28	2023-06-28	0	0	0	0	EMIStartDate	\N
372	FD_Detail_Verify	sid	string	\N	\N	0	0	0	0	sid	\N
373	FD_Select	sid	string	\N	\N	0	0	0	0	sid	\N
374	FD_Topup_Done	sid	string	\N	\N	0	0	0	0	sid	\N
375	Login	sid	string	\N	\N	0	0	0	0	sid	\N
376	GeoData_Received	sid	string	\N	\N	0	0	0	0	sid	\N
377	FD_Success	sid	string	\N	\N	0	0	0	0	sid	\N
378	CompanyDetails	sid	string	\N	\N	0	0	0	0	sid	\N
379	LogoutDetails	sid	string	\N	\N	0	0	0	0	sid	\N
380	EmployeeDetails	sid	string	\N	\N	0	0	0	0	sid	\N
381	FD_Cancel	sid	string	\N	\N	0	0	0	0	sid	\N
382	ping_location	sid	string	\N	\N	0	0	0	0	sid	\N
98	Campaign_Deleted	campid	int	\N	\N	123456789	1	0	0	campid	\N
97	Campaign_Viewed	campid	int	\N	\N	321321112	1	0	0	campid	\N
4	Campaign_Received	campid	string	\N	\N	321321112	0	0	0	campid	\N
421	Event Rose	integrations	object	\N	\N	0	0	0	0	\N	\N
435	RTG9	Ci	string	\N	\N	0	0	0	0	\N	\N
441	RTG15	Ci	string	\N	\N	0	0	0	0	\N	\N
447	RTG25	Ci	string	\N	\N	0	0	0	0	\N	\N
451	RTG29	Ci	string	\N	\N	0	0	0	0	\N	\N
457	RTG39	Ci	string	\N	\N	0	0	0	0	\N	\N
458	RTG40	Ci	string	\N	\N	0	0	0	0	\N	\N
459	RTG41	Ci	string	\N	\N	0	0	0	0	\N	\N
\.


--
-- Name: attributes_5bebe93c25d705690ffbc758_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attributes_5bebe93c25d705690ffbc758_id_seq', 460, true);


--
-- Name: attributes_5bebe93c25d705690ffbc758 attributes_5bebe93c25d705690ffbc758_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attributes_5bebe93c25d705690ffbc758
    ADD CONSTRAINT attributes_5bebe93c25d705690ffbc758_pkey PRIMARY KEY (key, name);


--
-- PostgreSQL database dump complete
--

