--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3 (Ubuntu 14.3-1.pgdg20.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: events_5bebe93c25d705690ffbc758_07012024; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events_5bebe93c25d705690ffbc758_07012024 (
    key character varying(200),
    eventtime integer,
    did character varying(200),
    sid character varying(200),
    did_sid text,
    utime integer,
    platform character varying(20),
    dt date,
    segment jsonb
);


ALTER TABLE public.events_5bebe93c25d705690ffbc758_07012024 OWNER TO postgres;

--
-- Data for Name: events_5bebe93c25d705690ffbc758_07012024; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events_5bebe93c25d705690ffbc758_07012024 (key, eventtime, did, sid, did_sid, utime, platform, dt, segment) FROM stdin;
Campaign_Received	1704587406	c2534f67-f2b3-410b-a6a5-3c4512da93d0	dcae78ae-e6da-4fc9-8961-d26b270649d3	c2534f67-f2b3-410b-a6a5-3c4512da93d0_dcae78ae-e6da-4fc9-8961-d26b270649d3	1704587408	Android	2024-01-07	{"campid": "643f8658ab4a662ea2274bc2"}
Campaign_Received	1704594627	c2534f67-f2b3-410b-a6a5-3c4512da93d0	dcae78ae-e6da-4fc9-8961-d26b270649d3	c2534f67-f2b3-410b-a6a5-3c4512da93d0_dcae78ae-e6da-4fc9-8961-d26b270649d3	1704594629	Android	2024-01-07	{"campid": "643f8658ab4a662ea2274bc2"}
Campaign_Received	1704609132	c2534f67-f2b3-410b-a6a5-3c4512da93d0	dcae78ae-e6da-4fc9-8961-d26b270649d3	c2534f67-f2b3-410b-a6a5-3c4512da93d0_dcae78ae-e6da-4fc9-8961-d26b270649d3	1704609134	Android	2024-01-07	{"campid": "643f8658ab4a662ea2274bc2"}
Campaign_Received	1704616208	c2534f67-f2b3-410b-a6a5-3c4512da93d0	dcae78ae-e6da-4fc9-8961-d26b270649d3	c2534f67-f2b3-410b-a6a5-3c4512da93d0_dcae78ae-e6da-4fc9-8961-d26b270649d3	1704616210	Android	2024-01-07	{"campid": "643f8658ab4a662ea2274bc2"}
Campaign_Received	1704623407	c2534f67-f2b3-410b-a6a5-3c4512da93d0	dcae78ae-e6da-4fc9-8961-d26b270649d3	c2534f67-f2b3-410b-a6a5-3c4512da93d0_dcae78ae-e6da-4fc9-8961-d26b270649d3	1704623409	Android	2024-01-07	{"campid": "643f8658ab4a662ea2274bc2"}
Campaign_Received	1704630666	c2534f67-f2b3-410b-a6a5-3c4512da93d0	dcae78ae-e6da-4fc9-8961-d26b270649d3	c2534f67-f2b3-410b-a6a5-3c4512da93d0_dcae78ae-e6da-4fc9-8961-d26b270649d3	1704630668	Android	2024-01-07	{"campid": "643f8658ab4a662ea2274bc2"}
Campaign_Received	1704637811	c2534f67-f2b3-410b-a6a5-3c4512da93d0	dcae78ae-e6da-4fc9-8961-d26b270649d3	c2534f67-f2b3-410b-a6a5-3c4512da93d0_dcae78ae-e6da-4fc9-8961-d26b270649d3	1704637813	Android	2024-01-07	{"campid": "643f8658ab4a662ea2274bc2"}
Campaign_Received	1704645007	c2534f67-f2b3-410b-a6a5-3c4512da93d0	dcae78ae-e6da-4fc9-8961-d26b270649d3	c2534f67-f2b3-410b-a6a5-3c4512da93d0_dcae78ae-e6da-4fc9-8961-d26b270649d3	1704645010	Android	2024-01-07	{"campid": "643f8658ab4a662ea2274bc2"}
\.


--
-- Name: events_5bebe93c25d705690ffbc758_07012024_eventtime_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_5bebe93c25d705690ffbc758_07012024_eventtime_idx ON public.events_5bebe93c25d705690ffbc758_07012024 USING brin (eventtime);


--
-- Name: events_5bebe93c25d705690ffbc758_07012024_key_did_sid_et_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_5bebe93c25d705690ffbc758_07012024_key_did_sid_et_idx ON public.events_5bebe93c25d705690ffbc758_07012024 USING btree (key, did_sid, eventtime);


--
-- Name: events_5bebe93c25d705690ffbc758_07012024_key_did_sid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_5bebe93c25d705690ffbc758_07012024_key_did_sid_idx ON public.events_5bebe93c25d705690ffbc758_07012024 USING btree (key, did_sid);


--
-- Name: events_5bebe93c25d705690ffbc758_07012024_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_5bebe93c25d705690ffbc758_07012024_key_idx ON public.events_5bebe93c25d705690ffbc758_07012024 USING btree (key);


--
-- PostgreSQL database dump complete
--

