--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3 (Ubuntu 14.3-1.pgdg20.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: temp_app_users_5bebe93c25d705690ffbc758; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp_app_users_5bebe93c25d705690ffbc758 (
    inittime bigint,
    fs integer,
    ls integer,
    did character varying(250),
    cty character varying(100),
    cc character varying(100),
    country character varying(100),
    region character varying(100),
    active boolean,
    sdkv character varying(50),
    sdkiv character varying(50),
    p character varying(50),
    pv character varying(50),
    av character varying(50),
    ac character varying(50),
    d character varying(150),
    c character varying(50),
    res character varying(100),
    l character varying(50),
    tz integer,
    _app_pack character varying(250),
    sc integer,
    tsd integer,
    lsd integer,
    ls_st integer,
    history jsonb,
    gcmid character varying(1000),
    fcmid character varying(1000),
    playservice jsonb,
    permissions jsonb,
    competingapps jsonb,
    interests jsonb,
    user_info jsonb,
    _custom jsonb,
    le jsonb,
    el jsonb,
    eventstring character varying,
    createdat integer,
    updatedat integer,
    _custom_userid character varying(50),
    ma character varying,
    mo character varying,
    device_lang character varying
);


ALTER TABLE public.temp_app_users_5bebe93c25d705690ffbc758 OWNER TO postgres;

--
-- Data for Name: temp_app_users_5bebe93c25d705690ffbc758; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp_app_users_5bebe93c25d705690ffbc758 (inittime, fs, ls, did, cty, cc, country, region, active, sdkv, sdkiv, p, pv, av, ac, d, c, res, l, tz, _app_pack, sc, tsd, lsd, ls_st, history, gcmid, fcmid, playservice, permissions, competingapps, interests, user_info, _custom, le, el, eventstring, createdat, updatedat, _custom_userid, ma, mo, device_lang) FROM stdin;
1657719182	1657719182	1657719182	2f2453ec-2161-7b37-8d3c-297e358c5690	Delhi	IN	India		t	SDK_v2.5.8	258	Web	Linux	1_0_0	Webkit	Web	undefined	393 X 873	En-GB	19800	abc	0	0	0	0	[{"type": "I", "isnew": true, "dtEntry": 1657719182, "refname": "self", "createdBy": "sdk", "installer": "Self", "ip_address": "103.87.57.167"}]			[]	[]	[]	[]	[]	[]	[]	[]	D130722S1T1657719182B10T1657719182A9V16A10V1A11V229B9T1658599572A8V15E1T1658599572D230722S2T1658599572E2T1658599572	1657719189	1657719189	\N			19
\.


--
-- PostgreSQL database dump complete
--

