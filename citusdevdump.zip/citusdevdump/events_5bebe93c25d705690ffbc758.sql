--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3 (Ubuntu 14.3-1.pgdg20.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: events_5bebe93c25d705690ffbc758; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events_5bebe93c25d705690ffbc758 (
    appid character varying(150),
    did character varying(200),
    key character varying(200),
    sid character varying(200),
    p character varying(20),
    rtime integer,
    utime integer,
    segment jsonb,
    context jsonb,
    eventtime integer,
    dt date,
    createat date
)
PARTITION BY RANGE (dt);


ALTER TABLE public.events_5bebe93c25d705690ffbc758 OWNER TO postgres;

--
-- Name: events_5bebe93c25d705690ffbc758_eventtime_brin_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_5bebe93c25d705690ffbc758_eventtime_brin_idx ON ONLY public.events_5bebe93c25d705690ffbc758 USING brin (eventtime);


--
-- Name: events_5bebe93c25d705690ffbc758_key_did_dt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_5bebe93c25d705690ffbc758_key_did_dt_idx ON ONLY public.events_5bebe93c25d705690ffbc758 USING btree (key, did, dt DESC);


--
-- Name: events_5bebe93c25d705690ffbc758_p_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_5bebe93c25d705690ffbc758_p_idx ON ONLY public.events_5bebe93c25d705690ffbc758 USING btree (p);


--
-- PostgreSQL database dump complete
--

